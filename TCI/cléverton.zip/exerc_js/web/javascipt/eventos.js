$(document).ready(function () {


    /*$("p").click(function(){   //um click
     
     $(this).hide();
     
     });
     
     $("p").dblclick(function(){    //dois click
     
     $(this).hide();
     
     });
     
     $("p").mouseenter(function(){
     
     //$(this).hide();
     
     alert("Você esta sendo filmado!");
     
     });
     
     $("p").mouseleave(function(){
     
     alert("Não se váááááá!");
     
     });
     
     $("p").mousedown(function(){
     
     alert("Não se váááááá!");
     
     });
     
     $("p").mouseup(function(){
     
     alert("Não se váááááá!");
     
     });
     
     $("p").hover(function(){
     
     alert("Não se váááááá!");
     
     });
     
     $("#nome").focus(function(){
     
     alert("Digite seu nome!");
     
     });
     
     $("#email").focus(function(){
     
     alert("Digite seu email!");
     
     });*/

    $("input").focus(function () {

        $(this).css({"background-color": "red", "font-size": "16px"});

    });

    $("input").blur(function () {

        $(this).css({"background-color": "blue", "font-size": "12px"});

    });

    $("button").click(function () {
        $("body").css({"background-color": "green",
            "font-size": "12px"
        });
    });

    $("button").dblclick(function () {
        $("body").css({"background-color": "blue", "font-size": "20px"});
    });


});


