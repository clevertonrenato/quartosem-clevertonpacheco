function exerc_1(){
    
    alert("Mensagem");
    
    confirm("Mensagem");
    
    prompt("Mensagem", "Ajuda");
    
    
}


