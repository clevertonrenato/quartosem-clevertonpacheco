$(document).ready(function(){
   
    
    $('#fade').inewsticker({
       
       effect: 'fade',
       speed: 4000,
       delay_after: 4000,
       font_family: 'Verdana',
       font_size: 20
        
    });
    
    $('#slide').inewsticker({
       
       effect: 'slide',
       speed: 4000,
       delay_after: 4000,
       font_family: 'Verdana',
       font_size: 20
        
    });  
    
    $('#typing').inewsticker({
       
       effect: 'typing',
       speed: 80,
       delay_after: 4000,
       font_family: 'Verdana',
       font_size: 20
        
    });     
    
    
});