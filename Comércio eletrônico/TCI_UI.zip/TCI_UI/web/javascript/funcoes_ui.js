$(function() {
    $("#noticias").accordion();
    
    
    
    var vPalavras = ["Cleverton","Diosefer", 
        "Patrick", "Rosimeri", "Mario", "Darlene"];

    $("#palavras").autocomplete({
       source: vPalavras 
    });
    
    
    
    $("#dataNasc").datepicker();
    
    
    $("#tabs").tabs();
    
});