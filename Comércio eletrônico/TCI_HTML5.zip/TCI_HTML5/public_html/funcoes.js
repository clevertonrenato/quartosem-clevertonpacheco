function corFundo(cor1){
    
    varCor = document.getElementById(cor1).value;
    document.getElementById('corpo').style.backgroundColor = varCor;
    
}