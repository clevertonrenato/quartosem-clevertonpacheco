$(document).ready(function() {

    /*
     * 
     *
     *     
     
     
     
     $("#topo").click(function(){
     
     $("#corpo").toggle(300);
     
     });
     
     $("#topo").click(function(){
     
     $("#corpo").fadeIn(300);
     
     });
     
     $("#topo").click(function(){
     
     $("#corpo").fadeOut(300);
     
     });    
     
     $("#topo").click(function(){
     
     $("#corpo").fadeToggle(800);
     
     });
     
     $("#topo").click(function(){
     
     $("#corpo").slideUp();
     
     });
     
     $("#topo").dblclick(function(){
     
     $("#corpo").slideDown();
     
     });    
     
     $("#topo").click(function() {
     
     $("#corpo").slideToggle();
     
     });
     
     
     $("#topo").click(function() {
     
     $("#corpo").animate({ left: '250px' });
     
     });
     
     $("#topo").click(function() {
     
     $("#corpo").animate({
     left: '250px',
     width: '800px',
     height: '400px',
     opacity: '0.5'                   
     });
     
     });
     
     */

    $("#topo").click(function() {

        $("#corpo").animate({
            left: '250px',
            width: '800px',
            height: '400px',
            opacity: '0.5'
        });

    });




});