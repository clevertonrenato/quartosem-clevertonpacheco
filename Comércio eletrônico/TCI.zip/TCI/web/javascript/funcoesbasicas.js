$(document).ready(function(){
    
  /* hide - esconde o objeto
    $("button").click(function(){
        $("p").hide();
    });    
    
    
    $("button").click(function(){
        $("#p1").hide();
    });
    */
   
    $("button").click(function(){
        $(this).hide();
    });
   
    
    
});